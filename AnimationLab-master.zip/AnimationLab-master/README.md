# AnimationLab
Note: As this lab is for artists, you will most likely want to create your own sprites and assets, and will be using a blank Unity project to do the animating. 
If you are a programmer and want to complete this lab, you may use the sprites that have been included in this repo. Good luck!
